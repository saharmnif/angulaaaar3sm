import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bleudechanel',
  templateUrl: './bleudechanel.component.html',
  styleUrls: ['./bleudechanel.component.css']
})
export class BleudechanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
