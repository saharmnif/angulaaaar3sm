import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-you',
  templateUrl: './you.component.html',
  styleUrls: ['./you.component.css']
})
export class YouComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute) { }
  identifiant2:number = 0;
  ngOnInit(): void {
    this.identifiant2 = this.activatedRoute.snapshot.params['idy'];
  }

}
