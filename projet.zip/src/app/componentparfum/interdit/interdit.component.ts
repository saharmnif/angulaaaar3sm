import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interdit',
  templateUrl: './interdit.component.html',
  styleUrls: ['./interdit.component.css']
})
export class InterditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
