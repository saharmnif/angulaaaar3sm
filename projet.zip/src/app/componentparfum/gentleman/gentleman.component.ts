import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gentleman',
  templateUrl: './gentleman.component.html',
  styleUrls: ['./gentleman.component.css']
})
export class GentlemanComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
