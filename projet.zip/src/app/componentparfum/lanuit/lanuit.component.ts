import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-lanuit',
  templateUrl: './lanuit.component.html',
  styleUrls: ['./lanuit.component.css']
})
export class LanuitComponent implements OnInit {

  constructor(private activatedRoute:ActivatedRoute) { }

  //identifiant1:number=0;

  ngOnInit(): void {
    //this.identifiant1= this.activatedRoute.snapshot.params['idn'];
  
  }
  }



