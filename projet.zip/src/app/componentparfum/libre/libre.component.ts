import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-libre',
  templateUrl: './libre.component.html',
  styleUrls: ['./libre.component.css']
})
export class LibreComponent implements OnInit {
 // constructor(private activatedRoute:ActivatedRoute) { }
 //identifiant:number = 0;
  ngOnInit(): void {
  // this.identifiant = this.activatedRoute.snapshot.params['idl'];
  }

}
