import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './component/menu/menu.component';
import { AcceuilComponent } from './component/acceuil/acceuil.component';

import { ErreurComponent } from './component/erreur/erreur.component';
import { NosparfumComponent } from './component/nosparfum/nosparfum.component';
import { InscrireComponent } from './component/inscrire/inscrire.component';
import { MagasinComponent } from './component/magasin/magasin.component';
import { LibreComponent } from './componentparfum/libre/libre.component';
import { InterditComponent } from './componentparfum/interdit/interdit.component';
import { YouComponent } from './componentparfum/you/you.component';
import { GentlemanComponent } from './componentparfum/gentleman/gentleman.component';
import { LanuitComponent } from './componentparfum/lanuit/lanuit.component';
import { BleudechanelComponent } from './componentparfum/bleudechanel/bleudechanel.component';
import { SelectedparfumComponent } from './ex/selectedparfum/selectedparfum.component';

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    AcceuilComponent,

    ErreurComponent,
    NosparfumComponent,
    InscrireComponent,
    MagasinComponent,
    LibreComponent,
    InterditComponent,
    YouComponent,
    GentlemanComponent,
    LanuitComponent,
    BleudechanelComponent,
    SelectedparfumComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
