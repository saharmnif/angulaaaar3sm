import { Injectable } from '@angular/core';
import { Parfum } from '../Model/parfum';

@Injectable({
  providedIn: 'root'
})
export class ParfumService {
  private parfum: Parfum[]=[
    new Parfum ( 22, 'libre', 'assets/libre.jpg', 98.29, true, new Date (2022) , 'femme' , 'eau de parfum ', 'yves saint laurent '),
    new Parfum ( 44, "la nuit de l'homme", "assets/la nuit de l'homme.jpg", 98.00, false, new Date (2006) , 'homme' , 'eau de parfum ', 'yves saint laurent '),
   new Parfum ( 66, 'you', 'assets/you.jpg', 65.00, true, new Date (2017) , 'femme' , 'eau de parfum', 'armani'),
    new Parfum ( 88, 'bleu de chanel', 'assets/bleu de chanel.jpg', 86.00, false, new Date (2010) , 'homme' , 'eau de parfum', 'chanel '),
    new Parfum ( 100, "l'interdit", 'assets/l-interdit.jpg', 94.00, true, new Date (2018) , 'femme' , 'eau de parfum', 'givenchy '),
    new Parfum ( 122, "gentleman", 'assets/gentleman.jpg', 81.100, true, new Date (2017) , 'homme' , 'eau de parfum', 'givenchy '),
   
    ];
    getProduits ()
   {
   return  this.parfum;
   }
   getLivreById(id :number) {
    return( this.parfum.find(elt=>elt.id==id)) ;
   }

  constructor() { }

}
