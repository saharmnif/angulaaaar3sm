export class Parfum {
    constructor (

        public id:number,
        public nom:string, 
       public photo :string ,
       public prix : number ,
       public nouveau: Boolean ,
       public datecreation : Date ,
       public categorie : string ,
       public typeparfum : string ,
       public marque : string ,
     
       

        )
        {}
}
