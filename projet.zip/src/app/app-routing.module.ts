import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AcceuilComponent } from './component/acceuil/acceuil.component';
import { ErreurComponent } from './component/erreur/erreur.component';
import { MagasinComponent } from './component/magasin/magasin.component';
import { MenuComponent } from './component/menu/menu.component';
import { NosparfumComponent } from './component/nosparfum/nosparfum.component';
import { BleudechanelComponent } from './componentparfum/bleudechanel/bleudechanel.component';
import { GentlemanComponent } from './componentparfum/gentleman/gentleman.component';
import { InterditComponent } from './componentparfum/interdit/interdit.component';
import { LanuitComponent } from './componentparfum/lanuit/lanuit.component';
import { LibreComponent } from './componentparfum/libre/libre.component';
import { YouComponent } from './componentparfum/you/you.component';
import { SelectedparfumComponent } from './ex/selectedparfum/selectedparfum.component';
const routes: Routes = [
  {path:'accueil',title:'accueil', component:AcceuilComponent},
  {path:'menu' , title:'menu', component:MenuComponent},
  {path:'nosparfum'   , title:'nosparfum' ,component: NosparfumComponent},
  {path:'nosparfum/:idl' ,title:'selectedparfum' , component: SelectedparfumComponent},
  //{  path:'nosparfum/:idl' ,title:'libre' , component:LibreComponent },
 // {  path:'nosparfum/:idn'   ,title:'lanuit' , component: LanuitComponent },
  //{  path:'nosparfum/:idy'  ,title:'you' , component: YouComponent},
  //{  path:'nosparfum/:idb'   ,title:'bleudechanel' , component: BleudechanelComponent },
  //{  path:'nosparfum/:idi'   ,title:'interdit' , component:InterditComponent },
   //{  path:'nosparfum/:idg'   ,title:'gentleman' , component: GentlemanComponent},
 
  {path:'magasin',title:'magasin' , component:MagasinComponent},
  {path:'', redirectTo:'accueil', pathMatch:'full'},
  {path:'**', title:'erreur', component: ErreurComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
