import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-magasin',
  templateUrl: './magasin.component.html',
  styleUrls: ['./magasin.component.css']
})
export class MagasinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
