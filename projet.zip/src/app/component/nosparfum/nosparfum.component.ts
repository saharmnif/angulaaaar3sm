import { Component, OnInit } from '@angular/core';
import { Parfum } from 'src/app/Model/parfum';
import { ParfumService } from 'src/app/service/parfum.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-nosparfum',
  templateUrl: './nosparfum.component.html',
  styleUrls: ['./nosparfum.component.css']
})
export class NosparfumComponent implements OnInit {

  constructor( private pfn: ParfumService , private activatedRoute:ActivatedRoute) { }
  variable= this.activatedRoute.snapshot.params['idl'];
  //variable1= this.activatedRoute.snapshot.params['idn'];
  //variable2= this.activatedRoute.snapshot.params['idy'];

  nosp : Parfum[];

  ngOnInit(): void {
    this.nosp=this.pfn.getProduits();
  }

}